---
name: General issue template
about: Use this template for any type of issue that is not related to a bug or feature
  request.
title: ''
labels: ''
assignees: ''

---


